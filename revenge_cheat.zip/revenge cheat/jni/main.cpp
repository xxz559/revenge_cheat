#include <jni.h>
#include <pthread.h>
#include <unistd.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <android/log.h>

#include "imgui.h"
#include "imgui_impl_android.h"
#include "imgui_impl_opengl3.h"
#include "cheats.h"

bool imgui_initialized = false;
bool menu_visible = true;

// Функция отрисовки интерфейса графического меню ImGui
void DrawMinecraftMenu() {
    ImGui::SetNextWindowSize(ImVec2(450, 320), ImGuiCond_FirstUseEver);
        
            if (ImGui::Begin("Minecraft 1.21.111 Mod Menu", &menu_visible, ImGuiWindowFlags_NoResize)) {
                    ImGui::Text("Система инициализирована. Базовый адрес: %p", (void*)game_base_address);
                            ImGui::Separator();

                                    if (ImGui::Checkbox("Включить X-Ray", &xray_active)) {
                                                set_xray_state(game_base_address, xray_active);
                                                        }

                                                                ImGui::Checkbox("Включить ESP (Квадраты)", &esp_enabled);

                                                                        ImGui::Separator();
                                                                                if (ImGui::Button("Скрыть меню")) {
                                                                                            menu_visible = false;
                                                                                                    }
                                                                                                            
                                                                                                                    ImGui::End();
                                                                                                                        }

                                                                                                                            if (esp_enabled) {
                                                                                                                                    process_esp_logic();
                                                                                                                                        }
                                                                                                                                        }

                                                                                                                                        // Хук-функция для встраивания отрисовки ImGui в графический конвейер игры
                                                                                                                                        EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
                                                                                                                                            if (!imgui_initialized) {
                                                                                                                                                    IMGUI_CHECKVERSION();
                                                                                                                                                            ImGui::CreateContext();
                                                                                                                                                                    
                                                                                                                                                                            ImGui::StyleColorsDark();

                                                                                                                                                                                    ImGui_ImplAndroid_Init(nullptr);
                                                                                                                                                                                            ImGui_ImplOpenGL3_Init("#version 300 es");

                                                                                                                                                                                                    imgui_initialized = true;
                                                                                                                                                                                                        }

                                                                                                                                                                                                            ImGui_ImplOpenGL3_NewFrame();
                                                                                                                                                                                                                ImGui_ImplAndroid_NewFrame();
                                                                                                                                                                                                                    ImGui::NewFrame();

                                                                                                                                                                                                                        if (menu_visible) {
                                                                                                                                                                                                                                DrawMinecraftMenu();
                                                                                                                                                                                                                                    }

                                                                                                                                                                                                                                        ImGui::Render();
                                                                                                                                                                                                                                            ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

                                                                                                                                                                                                                                                return EGL_TRUE; 
                                                                                                                                                                                                                                                }

                                                                                                                                                                                                                                                // Поток инициализации модуля чита внутри процесса Minecraft 1.21.111
                                                                                                                                                                                                                                                void* cheat_init_thread(void*) {
                                                                                                                                                                                                                                                    __android_log_print(ANDROID_LOG_INFO, "MC_MAIN", "Ожидание загрузки libminecraftpe.so...");
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                            while (game_base_address == 0) {
                                                                                                                                                                                                                                                                    game_base_address = get_module_base("libminecraftpe.so");
                                                                                                                                                                                                                                                                            usleep(500000); 
                                                                                                                                                                                                                                                                                }

                                                                                                                                                                                                                                                                                    __android_log_print(ANDROID_LOG_INFO, "MC_MAIN", "Модуль игры обнаружен. База: %p", (void*)game_base_address);
                                                                                                                                                                                                                                                                                        return nullptr;
                                                                                                                                                                                                                                                                                        }

                                                                                                                                                                                                                                                                                        JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) {
                                                                                                                                                                                                                                                                                            pthread_t thread;
                                                                                                                                                                                                                                                                                                pthread_create(&thread, nullptr, cheat_init_thread, nullptr);
                                                                                                                                                                                                                                                                                                    return JNI_VERSION_1_6;
                                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                                    