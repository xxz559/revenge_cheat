LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE    := McModMenu

# Пути ко всем исходным файлам проекта
LOCAL_SRC_FILES := main.cpp \
                   cheats.cpp \
				                      imgui/imgui.cpp \
									                     imgui/imgui_draw.cpp \
														                    imgui/imgui_widgets.cpp \
																			                   imgui/imgui_tables.cpp \
																							                      imgui/backends/imgui_impl_android.cpp \
																												                     imgui/backends/imgui_impl_opengl3.cpp

																																	 # Пути, где компилятор ищет заголовочные файлы (.h)
																																	 LOCAL_C_INCLUDES := $(LOCAL_PATH) \
																																	                     $(LOCAL_PATH)/imgui \
																																						                     $(LOCAL_PATH)/imgui/backends

																																											 # Подключение системных библиотек Android для логирования и работы с графикой OpenGL ES 3
																																											 LOCAL_LDLIBS    := -llog -lGLESv3 -lEGL

																																											 include $(BUILD_SHARED_LIBRARY)
																																											 