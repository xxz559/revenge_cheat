APP_STL := c++_shared
APP_BUILD_SCRIPT := jni/Android.mk
APP_ABI := arm64-v8a
APP_PLATFORM := android-24
APP_OPTIM := release
