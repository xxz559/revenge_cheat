#include "imgui.h"
#include <stdarg.h>

namespace ImGui {
    ImGuiContext* CreateContext() { return nullptr; }
        void StyleColorsDark() {}
            bool Begin(const char* name, bool* p_open, int flags) { return true; }
                void End() {}
                    void Text(const char* fmt, ...) {}
                        void Separator() {}
                            bool Checkbox(const char* label, bool* v) { return false; }
                                bool Button(const char* label, const ImVec2& size) { return false; }
                                    void Render() {}
                                        ImDrawData* GetDrawData() { return nullptr; }
                                            void SetNextWindowSize(const ImVec2& size, int cond) {}
                                                void SetItemTooltip(const char* fmt, ...) {}
                                                }
                                                