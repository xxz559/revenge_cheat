#pragma once
#include <stddef.h>

struct ImVec2 { float x, y; ImVec2() { x = y = 0.0f; } ImVec2(float _x, float _y) { x = _x; y = _y; } };
struct ImDrawData;

namespace ImGui {
    struct ImGuiContext;
        ImGuiContext* CreateContext();
            void StyleColorsDark();
                bool Begin(const char* name, bool* p_open = NULL, int flags = 0);
                    void End();
                        void Text(const char* fmt, ...);
                            void Separator();
                                bool Checkbox(const char* label, bool* v);
                                    bool Button(const char* label, const ImVec2& size = ImVec2(0,0));
                                        void Render();
                                            ImDrawData* GetDrawData();
                                                void SetNextWindowSize(const ImVec2& size, int cond = 0);
                                                    void SetItemTooltip(const char* fmt, ...);
                                                    }

                                                    #define IMGUI_CHECKVERSION() thread_local int imgui_ver = 0;
                                                    enum ImGuiCond_ { ImGuiCond_FirstUseEver = 1 };
                                                    enum ImGuiWindowFlags_ { ImGuiWindowFlags_NoResize = 1 << 1 };
                                                    