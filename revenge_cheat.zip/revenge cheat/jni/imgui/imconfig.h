#pragma once
// Базовая конфигурация для Android
#define IMGUI_DISABLE_WIN32_FUNCTIONS
#define IMGUI_DISABLE_METERS
