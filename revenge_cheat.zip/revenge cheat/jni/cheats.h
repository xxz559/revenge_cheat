#pragma once
#include <stdint.h>

// Базовая структура для работы с трехмерными координатами в пространстве игры
struct Vector3 {
    float x;
        float y;
            float z;
            };

            // Структура сущности игрока/моба
            struct Actor {
                char pad_0000[0x4C]; // Смещение до позиции (определяется анализом структуры)
                    Vector3 position;     
                        float health;         
                        };

                        // Объявление глобальных переменных состояния функций чита
                        extern bool xray_active;
                        extern bool esp_enabled;
                        extern uintptr_t game_base_address;

                        // Объявление функций
                        uintptr_t get_module_base(const char* module_name);
                        void set_xray_state(uintptr_t base_address, bool enable);
                        void process_esp_logic();
                        